<?php
namespace App\Controllers;
use CodeIgniter\Controller;

class backend03 extends Controller {
    public function index()
    {
        // $myArray = array(10,1,6,8,5);
        $myArray = array(3,8,5,2);

        // Coding back-end 03 here!!!! 

        // 62160109 วิรัตน์ สากร
        // Wirat Sakorn
        $myArraySorted = $myArray;
        sort($myArraySorted);

        $rangeArray = range(min($myArraySorted),max($myArraySorted));
        $missingArray = (array_diff($rangeArray, $myArraySorted));
        
        echo "MyArray value : ";
        foreach ($myArray AS $value) {
            echo " " . $value;
        }
        echo "<br />";

        echo "Expected value : ";
        foreach ($missingArray AS $value) {
            echo " " . $value;
        }
        echo "<br />";

        // Coding back-end 03 here!!!! 
    }
}
?>